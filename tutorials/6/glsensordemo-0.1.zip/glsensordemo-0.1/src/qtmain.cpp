/*
 * Created: 03/31/10-15:40:31
 * Author: Peter Bouda
 * Website: www.mobileqt.de
 * License: GNU LESSER GENERAL PUBLIC LICENSE
 */
#include <QApplication>
#include <QtOpenGL>
#include "glwidget.h"

int main(int argc, char *argv[])
{
	QApplication app(argc, argv);

        if (!QGLFormat::hasOpenGL() || !QGLFramebufferObject::hasOpenGLFramebufferObjects()) {
            QMessageBox::information(0, "OpenGL framebuffer objects",
                                     "This system does not support OpenGL/framebuffer objects.");
            return -1;
        }

        GLWidget widget(0);
        widget.show();
        app.setQuitOnLastWindowClosed(true);
        return app.exec();
}

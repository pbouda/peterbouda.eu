/*
 * Created: 03/31/10-15:40:31
 * Author: Peter Bouda
 * Website: www.mobileqt.de
 * License: GNU LESSER GENERAL PUBLIC LICENSE
 */

#ifndef GLWIDGET_H
#define GLWIDGET_H

#include <QtOpenGL>
#include <QAccelerometer>

class QtLogo;

class GLWidget : public QGLWidget {
    Q_OBJECT
public:
    explicit GLWidget(QWidget *parent = 0);
    ~GLWidget();

    QSize minimumSizeHint() const;
    QSize sizeHint() const;

public slots:
     void setXRotation(int angle);
     void setYRotation(int angle);
     void setZRotation(int angle);

protected:
    void initializeGL();
    void paintGL();
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
    void keyPressEvent (QKeyEvent * event);

signals:
    void xRotationChanged(int angle);
    void yRotationChanged(int angle);
    void zRotationChanged(int angle);

private:
    void paintQtLogo();
    void createGeometry();
    void quad(qreal x1, qreal y1, qreal x2, qreal y2, qreal x3, qreal y3, qreal x4, qreal y4);
    void extrude(qreal x1, qreal y1, qreal x2, qreal y2);
    qreal   m_fAngle;
    qreal   m_fScale;
    QVector<QVector3D> vertices;
    QVector<QVector3D> normals;
    QGLShaderProgram program1;
    int vertexAttr1;
    int normalAttr1;
    int matrixUniform1;
    int xRot;
    int yRot;
    int zRot;
    QPoint lastPos;
    QtMobility::QAccelerometer * _rotationSensor;
    bool _rotationSensorAvailable;

};

#endif // GLWIDGET_H
